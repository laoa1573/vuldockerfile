#!/bin/sh

PATH=/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin

chmod 777 /var/www/html/uploadfiles
nginx -s stop
nginx 